package edu.kosmo.ex.database;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;

import org.junit.Test;

import lombok.extern.log4j.Log4j;




@Log4j
public class JDBCTest { 	//3종세트로 했을때 junit 테스트

	public JDBCTest() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void testConnection() {
		
		  try (Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "scott",
		            "tiger")) {

		         System.out.println(con);
		      } catch (Exception e) {
		         fail(e.getMessage());
		      }

	}

}
