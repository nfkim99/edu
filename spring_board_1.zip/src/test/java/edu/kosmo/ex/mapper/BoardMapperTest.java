package edu.kosmo.ex.mapper;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.DriverManager;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import edu.kosmo.ex.vo.BoardVO;
import lombok.extern.log4j.Log4j;



// mybatis용 테스트 mapper

@RunWith(SpringRunner.class) // - 톰캣처럼 스프링 ioc 컨테이너를 만들어 주는 것!
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardMapperTest { 	
	
	@Inject // @autowired 랑 같은거 주입시켜줌
	private BoardMapper boardMapper; 
	
	
	@Test
	public void testBoardMapper() {
		
		assertNotNull(boardMapper);
		
		System.out.println(boardMapper);

	}
	
	@Test
	public void testInsert() {
		
		BoardVO board = new BoardVO();
		
		board.setBcontent("룰루랄라~");
		board.setBtitle("집에 가고싶다...피곤해ㅠ");
		board.setBname("둘리");
		
		boardMapper.insert(board);
		
		System.out.println(board);

	}
	

	@Test
	public void testGetlist() {
		
		
		for (BoardVO board : boardMapper.getList()) {
			System.out.println(board);
		}
		
		
	}
	
	
	

}
