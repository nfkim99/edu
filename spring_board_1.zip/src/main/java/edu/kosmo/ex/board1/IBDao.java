package edu.kosmo.ex.board1;

import java.util.ArrayList;

import edu.kosmo.ex.vo.BoardVO;


public interface IBDao {
	
	public ArrayList<BoardVO> listDao();

}
