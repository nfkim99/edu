package edu.kosmo.ex.mapper;



import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import edu.kosmo.ex.page.Criteria;
import edu.kosmo.ex.vo.BoardVO;

@Mapper
public interface BoardMapper {
	
	List<BoardVO> getList();
	BoardVO read(int bid);
	void insert(BoardVO board); 
	void delete(int bid); 
	void update(BoardVO board); 
	void updateHit(int bid);
	
	@Select("select * from mvc_board order by bgroup desc, bstep asc")
	public List<BoardVO> selectList();
	
	//void update(@Param("board") BoardVO board, @Param("emp") Emp emp);
	// 복수의 테이블을 받을시에는 @Param("board")를 쓰고 mapper.xml board.bname, board.bid, emp.bid, emp.bname 이런식으로 해줘야함!!!!
	// @Param("board") BoardVO board 로 넘으면 객체로 board.gid, board.bname 이렇게 넘긴다.
	// 단일 객체가 아닌 / 복수개의 파라미터를 넘길때에는 @Param("")으로 넘겨준다~
	//void update(@Param("bid") int bid, @Param("bcontent") String bcontent, @Param("title") String title);
	
	// 댓글관련
	void replyShape(BoardVO board);  
	void insertReply(BoardVO board);  
	
	//페이징 처리 관련
	int getTotalCount();
	List<BoardVO> getListWithPaging(Criteria criteria);
}
