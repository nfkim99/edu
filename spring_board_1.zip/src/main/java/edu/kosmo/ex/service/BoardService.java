package edu.kosmo.ex.service;

import java.util.List;

import edu.kosmo.ex.vo.BoardVO;

public interface BoardService {
	
	List<BoardVO> getList();
	BoardVO get(int bid);
	void write(BoardVO board);
	void delete(BoardVO board);
	void update(BoardVO board);
	void upHit(int bid);
	
	void insertReply(BoardVO board);
	
}
