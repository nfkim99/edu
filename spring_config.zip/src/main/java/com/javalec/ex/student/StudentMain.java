package com.javalec.ex.student;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class StudentMain {

	public static void main(String[] args) {
		
		AbstractApplicationContext ctx = new AnnotationConfigApplicationContext(ApplicationConfig.class);
		
		Student stu1 = ctx.getBean("student1", Student.class);
		System.out.println("이름 : " + stu1.getName());
		System.out.println("나이 : " + stu1.getAge());
		System.out.println("취미 : " + stu1.getHobbys());
		System.out.println("신장 : " + stu1.getHeight());
		System.out.println("몸무게 : " + stu1.getWeight());
		
		Student stu2 = ctx.getBean("student2", Student.class);
		System.out.println("이름 : " + stu2.getName());
		System.out.println("나이 : " + stu2.getAge());
		System.out.println("취미 : " + stu2.getHobbys());
		System.out.println("신장 : " + stu2.getHeight());
		System.out.println("몸무게 : " + stu2.getWeight());
		
	}

}
