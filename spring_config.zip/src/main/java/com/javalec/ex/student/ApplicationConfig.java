package com.javalec.ex.student;


import java.util.ArrayList;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.ImportResource;

@Configuration
@ImportResource("classpath:appCTX8.xml")
public class ApplicationConfig {
	
	@Bean
	public Student student1() {
		ArrayList<String> hobbys = new ArrayList<String>();
		hobbys.add("수영");
		hobbys.add("요리");
		
		Student stu1 = new Student("홍길동",20,hobbys);
		
		stu1.setHeight(180);
		stu1.setWeight(180);
		
		return stu1;
		
	}

	
}
