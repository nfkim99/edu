package edu.kosmo.ex.vo;

import static org.junit.Assert.*;

import org.junit.Test;

import lombok.extern.log4j.Log4j;

@Log4j
public class BoardVOTest {

	private BoardVO boardVO;
	
	public BoardVOTest() {
		boardVO = new BoardVO();
	}
	
	@Test
	public void testBoardVO() {
		assertNotNull(boardVO); // null 체크 - junit 제공함수 : assertNotNull
		
	}
	
	@Test
	public void testSetBname() {
		boardVO.setBname("Kim");
		assertEquals("Kim", boardVO.getBname()); // Bname에 kim이 있는가 비교
		
		
		System.out.println(boardVO.getBname());
		
	}
	
	@Test
	public void testGetBid() {
		boardVO.setBid(20);
		assertEquals(20, boardVO.getBid()); // Bname에 kim이 있는가 비교
		
		
		System.out.println(boardVO.getBid());
		
	}

}
