package edu.kosmo.ex.service;

import static org.junit.Assert.*;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import javax.sql.DataSource;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import edu.kosmo.ex.vo.BoardVO;
import lombok.extern.log4j.Log4j;



@RunWith(SpringRunner.class) // - 톰캣처럼 스프링 ioc 컨테이너를 만들어 주는 것!
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class BoardServiceTest {
	
	@Autowired
	private BoardService boardService;
	private BoardVO boardVO;
	
	
	
	@Ignore
	public void testBoardService() {
		
		assertNotNull(boardService);
		System.out.println(boardService);
		
	} 
	
	
	
	@Test
	public void testGetlist() {
		
		List<BoardVO> list = boardService.getList();

		for (BoardVO boardVO : list) {
			System.out.println(boardVO);
		}
	} 
	
	@Test
	public void testGet() {
	
		BoardVO get = boardService.get(490);
		System.out.println(get);
	
	} 
	
	@Test
	public void testDelete() {

		boardService.delete(490);
		
		BoardVO board = boardService.get(490);
		
		System.out.println("확인 = " + board);
	
	} 


}
