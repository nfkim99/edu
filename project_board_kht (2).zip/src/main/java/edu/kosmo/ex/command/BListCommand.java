package edu.kosmo.ex.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosmo.ex.dao.BDao;
import edu.kosmo.ex.dto.BDto;

public class BListCommand implements BCommand {
	
		@Override
		public void excute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		BDao dao = new BDao(); 
		ArrayList<BDto> dtos = dao.list();
		
		request.setAttribute("list", dtos); // 핵심코드 - 포워딩 될때까지 살아 있어라
		
		}

}
