package edu.kosmo.ex.service;

import java.util.List;

import edu.kosmo.ex.page.Criteria;
import edu.kosmo.ex.vo.BoardVO;

public interface BoardService {
	
	List<BoardVO> getList();
	BoardVO get(int bid);
	void write(BoardVO board);
	void delete(BoardVO board);
	void update(BoardVO board);
	void upHit(int bid);
	
	void insertReply(BoardVO board);
	
	//페이징 처리 함수 (위에랑똑같은거기때문에 함수 오버로딩을 적용시켰다)
	public int getTotal();
	public List<BoardVO> getList(Criteria criteria); // getList가 위에 있기 때문에 함수 오버로딩을 적용
	
}
