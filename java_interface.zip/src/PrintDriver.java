// 누군가가(갑님께서 = MS OS) 표준, 규약, 강제 이것밖에 없음

interface Printable {
	public abstract void print(String doc);
}

//.class
class SPrinterDriver implements Printable {
	@Override
	public void print(String doc) {
		System.out.println("From Samsung printer");
		System.out.println(doc);
	}
}

//.class
class LPrinterDriver implements Printable {
	@Override
	public void print(String doc) {
		System.out.println("From LG printer");
		System.out.println(doc);
	}
}


public class PrintDriver {

	public static void main(String[] args) {
		
		String myDoc = "This is a report about...";
	    
        // 삼성 프린터로 출력
        Printable prn = new SPrinterDriver();
        prn.print(myDoc);

        System.out.println();

        // LG 프린터로 출력
        prn = new LPrinterDriver();
        prn.print(myDoc);

	}

}
