// interface 가 나오게 된 배경

// 자바 = 단일상속
// 다중상속 지원

// 인터페이스 활용 => 약속, 규약, 강제 => 표준 
// 외주 줄때.

interface Printable2 {
	// 추상 메소드, 추상 함수, abstract (함수 선언만 가능) = 
	// 바디 실제 구현 부분이 없음
	// public abstract 는 생략 가능
	// 없으면 컴파일러가 붙여줌
	
	// abstract = 자손이 구현하라
	
	 void print(String doc);	// 함수 선언만 있음.
}



class Printer implements Printable2 {

	@Override
	public void print(String doc) {
		System.out.println(doc);	
	}
	
}

// 누군가가(갑님께서 = MS OS) 표준, 규약, 강제 이것밖에 없음

public class InterfaceTest {

	public static void main(String[] args) {
		
		Printable2 printable = new Printer();
		printable.print("Hello World");

	}

}
