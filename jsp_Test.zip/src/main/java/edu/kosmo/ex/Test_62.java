package edu.kosmo.ex;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Test_62
 */
@WebServlet("/rectangle")
public class Test_62 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Test_62() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html; charset=UTF-8");
		request.setCharacterEncoding("UTF-8");
		System.out.println("doGET");
		PrintWriter writer = response.getWriter(); // input/outputstream
		
		try {

			String[] hobbys = request.getParameterValues("hobby");
			String major = request.getParameter("major");
			String protocol = request.getParameter("protocol");

			//writer.println("취미는 : " + hobbys.toString() + "입니다.");
			writer.println("<h1>취미는 : " + Arrays.toString(hobbys) + "입니다.</h1>");
			writer.println("<h1>전공 : " + major + "입니다.</h1>");
			writer.println("<h1>프로토콜 : " + protocol + "입니다.</h1>");
		} catch (Exception e) {
			writer.println("에러 입니다.");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
