import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Set;
import java.util.StringTokenizer;

/*
 * 
	2.. 다음을 프로그래밍 하시오. 

		"그만"이 입력될 때까지 나라 이름과 인구를 입력 받아 저장하고, 다시 나라 이름을 입력받아 인구를 출력하는 프로그램을 작성하라. 
		다음 해시맵을 이용하라.
		=================================================================================
		나라 이름과 인구를 입력하세요.(예: Korea 5000)
		나라 이름, 인구 >> Korea 5000
		나라 이름, 인구 >> USA 1000000
		나라 이름, 인구 >> Swiss 2000
		나라 이름, 인구 >> France 3000
		나라 이름, 인구 >> 그만
		
		인구 검색 >> France
		France의 인구는 3000
		인구 검색 >> 스위스
		스위스 나라는 없습니다.
		인구 검색 >> 그만

 * 
 */

class Country2 {
	
	private HashMap<String, Integer> map;
	
	public Country2() {
		map = new HashMap<String, Integer>();
	}
	
	
	

	public HashMap<String, Integer> getMap() {
		
		System.out.println("나라 이름과 인구를 입력하세요.");
		
		
		try {
			Scanner sc = new Scanner(System.in);
			int population = 0;
			String country = "";
			
			while(true) {
				System.out.print("나라 이름, 인구 >> ");
				country = sc.next();
				
				if(country.equals("그만")) {
					break;
				}
				
				population = sc.nextInt();
				
				map.put(country, population);
			}
		} catch (Exception e) {
			System.out.println("잘못입력되었습니다. 다시입력하세요");
			getMap();
		}

		
		return map;
	}



	public void setMap(HashMap<String, Integer> map) {
		this.map = map;
	}



	public void search() {
		
		try {
			Scanner sc = new Scanner(System.in);
			
			String Key = "";
			
			while(true) {
				System.out.println("인구검색 >> ");
				Key = sc.next();
				
				if(Key.equals("그만")) {
					break;
					

				} else if(!map.containsKey(Key)) { // .containsKey = 글자를 넣어서 안에 Key 가 있는지 체크를 하는 함수
					System.out.println(Key + "나라는 없습니다.");
					continue;
					
				}
					
				
				System.out.println(Key + " " + map.get(Key));
				
			}
		} catch (Exception e) {
			System.out.println("잘못된 입력입니다. 다시 입력하세요.");
			search();
		}
		
		
		// country.bin 에 HashMap<String, Integer> map; 안에 저장된 나라와 인구수를 저장
		// I/O Stream 사용 
		public boolean saveFileMap() {
			
		}
		// I/O Stream 사용 
		// 저장된 country.bin 을 읽어 들여, HashMap<String, Integer> 으로 반환  
		public HashMap<String, Integer> readFileMap() {
		    
		}
		// I/O Stream 사용 
		// 저장된 country.bin 을 읽어 들여, 저장된 나라와 인구수를 출력
		public void printFileMap() {
				    
		}
		
	}
	
}

public class exTest4_Country2 {

	public static void main(String[] args) {
		
		Country countryMap = new Country();
		countryMap.getMap();
		countryMap.search();
	}

}
