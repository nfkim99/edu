import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class OutPut_Test2 {

	public static void main(String[] args) {

		OutputStream os = null; // 출력
		
		try {

			os = new FileOutputStream("love3.txt"); // 파일생성하기

			String str = "오늘 날씨는 아주 좋습니다.";	// 파일 내용
			InputStream is = null;
			byte[] bs = str.getBytes(); // 바이트 단위
			os.write(bs);  // 쓰기, 생성
			
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {
			try {
				if(os != null) {
					os.close(); // input, output은 항상 close 해줘야함
				}
			} catch (Exception e2) {
				
			}
		}

	}
}
