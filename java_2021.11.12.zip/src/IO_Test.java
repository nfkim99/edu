import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class IO_Test {

	public static void main(String[] args) {

		try {

			OutputStream os = new FileOutputStream("temp.bin");
			// 보조 스트림
			DataOutputStream dos = new DataOutputStream(os);

			dos.writeUTF("데이타스트림"); // UTF 형식으로 2byte 집어넣음
			dos.writeDouble(11.5);
			dos.writeInt(3);

			dos.flush(); // 이안에 남아있는 버퍼를 싹 비우는 거 == 집어넣음
			dos.close();

			InputStream is = new FileInputStream("temp.bin");
			DataInputStream dis = new DataInputStream(is);

			String name = dis.readUTF();
			double score = dis.readDouble();
			int order = dis.readInt();

			System.out.println(name + ":" + score + ":" + order);

			dis.close();

		} catch (Exception e) {
			e.printStackTrace();

		} finally {

		}

	}
}
