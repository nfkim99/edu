import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class InputOutPut_Test {

	public static void main(String[] args) {

		InputStream is = null; // 입력
		OutputStream os = null; // 출력
		
		try {

			is = new FileInputStream("love4.txt"); // 파일 읽기
			os = new FileOutputStream("love9.txt"); // 파일생성하기
			
			byte[] bs = new byte[5]; // 버퍼 5개씩 읽겠다는 의미
			
			
			
			while (true) {
				
				int count = is.read(bs); // 한 바이트씩 읽어드림.	 버퍼를 넣으면 값을 넣어줌
				
				if (count == -1) { // -1은 파일의 끝을 얘기함
					break;
				}
				
				os.write(bs,0,count);  // 쓰기, 생성
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			
		} finally {
			try {
				if(os != null) {
					os.close(); // input, output은 항상 close 해줘야함
					is.close();
				}
			} catch (Exception e2) {
				
			}
		}

	}
}
