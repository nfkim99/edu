package edu.kosmo.ex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

import org.apache.jasper.tagplugins.jstl.core.Out;

public class Lotto {

	private int lotto;
	private Set<Integer> lottoSet = new HashSet<Integer>();

	public Lotto() {
		this.lotto = (int)(Math.random() * 45 + 1); // 45 부터 1까지 랜덤함수 생성한다
		
		while(lottoSet.size() != 6) {
			int num = (int) (Math.random() * 45 + 1);
			lottoSet.add(num);
		}
	}

	public Set<Integer> getLottoSet() {
		return lottoSet;
	}

	public void setLottoSet(Set<Integer> lottoSet) {
		this.lottoSet = lottoSet;
	}


	
	public String result() { 
		
		String num2 = "";
		Set<Integer> set = new HashSet<>();
		

		while(set.size() != 6) {
			int num = (int) (Math.random() * 45 + 1);
			set.add(num);
		}
		
		for (Integer num : set) {
			System.out.print(num + "\t");
			num2 += num + " ";
		}
		
		System.out.println();
		
		return num2;
		

	}

}
