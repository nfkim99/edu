import java.util.Arrays;

/*
 * 사전식 정렬하여 출력하라
 */

// 자바에서 객체를 정렬
class Person3 implements Comparable {
	private String name;
	private int age;
	
	public Person3(String name, int age) {
		this.name = name;
		this.age = age;
	}
	

	
	@Override
	public int compareTo(Object o) {
		Person3 p = (Person3)o; 
		return this.name.compareTo(p.name); // 음수,양수,0만 리턴해주면 되어 자기자신을 기준 - 오름차순, 상대방을 기준 - 내림차순
	}
	
	
	@Override
	public String toString() {
		return name + ": " + age;
	}
	


}

public class Test2 {

	public static void main(String[] args) {
		
		Person3[] ar = new Person3[3];
		ar[0] = new Person3("Lee1234", 29);
		ar[1] = new Person3("Goo12", 15);
		ar[2] = new Person3("Soo3", 37);
		
		Arrays.sort(ar); // compareTo 호출시키는 주체
		
		System.out.println(Arrays.toString(ar));
	
		
	}
}




