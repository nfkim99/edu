import java.util.Random;

public class RandomTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 1970 1.1 0   .0.0.000 0 ~~~
		System.out.println(System.currentTimeMillis()); // 주로 처리속도를 알아볼떄 쓴다.
		
		Random rand = new Random();
		
		for(int i = 0; i < 7; i++) 
			System.out.println(rand.nextInt(1000));
		
		rand = new Random(12); //시드값
		
		for(int i = 0; i < 7; i++) 
			System.out.println(rand.nextInt(1000));
		
		System.out.println(System.currentTimeMillis());
		
	}
}
