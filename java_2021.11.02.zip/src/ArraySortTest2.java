import java.util.Arrays;


// 자바에서 객체를 정렬
class Person implements Comparable {
	private String name;
	private int age;
	
	public Person(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	@Override
	public int compareTo(Object o) {
		Person p = (Person)o; 
		return  p.name.length() - this.name.length(); // 음수,양수,0만 리턴해주면 되어 자기자신을 기준 - 오름차순, 상대방을 기준 - 내림차순
	}
	
	@Override
	public String toString() {
		return name + ": " + age;
	}

}

public class ArraySortTest2 {

	public static void main(String[] args) {
		
		Person[] ar = new Person[3];
		ar[0] = new Person("Lee1234", 29);
		ar[1] = new Person("Goo12", 15);
		ar[2] = new Person("Soo3", 37);
		
		Arrays.sort(ar); // compareTo 호출시키는 주체
		
		for (Person p : ar) {
			System.out.println(p);
		}
	
		
	}
}




