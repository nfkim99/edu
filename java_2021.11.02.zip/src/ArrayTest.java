import java.util.Arrays;
import java.util.Random;
import java.util.StringTokenizer;

public class ArrayTest {

	public static void main(String[] args) {
		double[] arOrg = {1.1, 2.2, 3.3, 4.4, 5.5};
		
		double[] arCpy1 = Arrays.copyOf(arOrg, arOrg.length);
		
		double[] arCpy2 = Arrays.copyOf(arOrg, 3);
		
		System.out.println(Arrays.toString(arOrg)); // Arrays.toString() 은 배열을 한꺼번에 뿌려준다.
		System.out.println(Arrays.toString(arCpy1));
		System.out.println(Arrays.toString(arCpy2));
		
		for(double d : arCpy1)
			System.out.print(d + "\t");
		System.out.println();
		
		for(double d : arCpy2)
			System.out.print(d + "\t");
		System.out.println();
		
		
		int[] ar1 = {1, 2, 3, 4, 5};
		int[] ar2 = Arrays.copyOf(ar1, ar1.length);
		
		System.out.println(Arrays.equals(ar1, ar2));
		
	}
}
