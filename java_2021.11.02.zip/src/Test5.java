import java.util.Arrays;

class Rectangle implements Comparable {
	private int width, height;

	public Rectangle(int width, int height) {
		this.width = width;
		this.height = height;
	}


	public int getArea() {
		int result = width * height;
		return result;
	}
	
	@Override
	public int compareTo(Object o) {
		Rectangle p = (Rectangle)o; 
		return  p.getArea() - this.getArea(); // 음수,양수,0만 리턴해주면 되어 자기자신을 기준 - 오름차순, 상대방을 기준 - 내림차순
	}
}

public class Test5 {

	public static void main(String[] args) {

		Rectangle[] recArr = { new Rectangle(6, 6), new Rectangle(5, 5), new Rectangle(10, 10), new Rectangle(12, 12),
				new Rectangle(11, 11) };

		Arrays.sort(recArr);

		for (Rectangle rec : recArr) {
			System.out.println(rec.getArea());
		}

	}
}
