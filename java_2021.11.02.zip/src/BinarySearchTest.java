import java.util.Arrays;

public class BinarySearchTest {

	public static void main(String[] args) {
	
		int[] ar = {33, 55, 11, 44, 22};
		Arrays.sort(ar); // 반드시 소팅 있어야함
		
		for (int n : ar) {
			System.out.println(n + "\t");
		}
		System.out.println();
		
		int idx = Arrays.binarySearch(ar, 33);
		System.out.println("Index of 33: " + idx);
	
		
	}
}




