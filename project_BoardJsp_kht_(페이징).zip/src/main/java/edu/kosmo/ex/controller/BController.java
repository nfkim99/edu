package edu.kosmo.ex.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosmo.ex.command.BCommand;
import edu.kosmo.ex.command.BContentCommand;
import edu.kosmo.ex.command.BDeleteCommand;
import edu.kosmo.ex.command.BListCommand;
import edu.kosmo.ex.command.BListCommand2;
import edu.kosmo.ex.command.BModifyCommand;
import edu.kosmo.ex.command.BReplyCommand;
import edu.kosmo.ex.command.BReplyViewCommand;
import edu.kosmo.ex.command.BWriteCommand;


/**
 * Servlet implementation class BCommand
 */
@WebServlet("*.do")
public class BController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		actionDo(request, response);
	}

	private void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("actionDO");
		
		request.setCharacterEncoding("UTF-8");
		
		String viewpage = null;
		BCommand command = null;
		
		String uri = request.getRequestURI();
		String conPath = request.getContextPath();
		String com = uri.substring(conPath.length());
		
		if(com.equals("/list.do")) {
			command = new BListCommand();
			command.excute(request, response);
			viewpage = "list.jsp";
		} else if(com.equals("/content_view.do")) {
			command = new BContentCommand();
			command.excute(request, response);
			viewpage = "content_view.jsp";
		} else if(com.equals("/write_view.do")) {
			viewpage = "write_view.jsp";
		} else if(com.equals("/write.do")) {
			command = new BWriteCommand();
			command.excute(request, response);
			viewpage = "list.do";
		} else if(com.equals("/modify_view.do")) {
			command = new BContentCommand();
			command.excute(request, response);
			viewpage = "modify_view.jsp";
		} else if(com.equals("/modify.do")) {
			command = new BModifyCommand();
			command.excute(request, response);
			viewpage = "list.do";
		} else if(com.equals("/delete_view.do")) {
			viewpage = "delete_view.jsp";
		} else if(com.equals("/delete.do")) {
			command = new BDeleteCommand();
			command.excute(request, response);
			viewpage = "list.do";
		} else if(com.equals("/reply_view.do")) {
			command = new BReplyViewCommand();
			command.excute(request, response);
			viewpage = "reply_view.jsp";
		} else if(com.equals("/reply.do")) {
			command = new BReplyCommand();
			command.excute(request, response);
			viewpage = "list.do";
		} else if(com.equals("/list2.do")) {
			command = new BListCommand2();
			command.excute(request, response);
			viewpage = "list2.do";
		} 
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(viewpage); // 핵심코드
		dispatcher.forward(request, response); // -> forwarding 되었기때문에 .do로 들어감
		
	}

}
