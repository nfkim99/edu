package edu.kosmo.ex.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosmo.ex.dao.BDao;
import edu.kosmo.ex.dto.BDto;
import edu.kosmo.ex.page.Criteria;

public class BListCommand2 implements BCommand {
	
		@Override
		public void excute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		BDao dao = new BDao(); 
		//ArrayList<BDto> dtos = dao.list(0, 0);
		
		Criteria criteria = new Criteria();
		
		
	    ArrayList<BDto> dtos = dao.list2(criteria);
	    

		request.setAttribute("list2", dtos); // 핵심코드 - 포워딩 될때까지 살아 있어라
		
		}

}
