package edu.kosmo.ex.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosmo.ex.dao.BDao;
import edu.kosmo.ex.dto.BDto;

public class BListCommand implements BCommand {
	
		@Override
		public void excute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		BDao dao = new BDao(); 
		//ArrayList<BDto> dtos = dao.list(0, 0);

		String strPg = request.getParameter("pg"); //list.jsp?pg=?
		 
	    int rowSize = 15; //한페이지에 보여줄 글의 수
	    int pg = 1; //페이지 , list.jsp로 넘어온 경우 , 초기값 =1
	   
	    if(strPg != null){ //list.jsp?pg=2
	        pg = Integer.parseInt(strPg); //.저장
	    }   
	   
	    int begin = (pg * rowSize) - (rowSize-1); //(1*10)-(10-1)=10-9=1 //from
	    int end=(pg * rowSize); //(1*10) = 10 //to
	 
	    ArrayList<BDto> dtos = dao.list(begin, end);

		request.setAttribute("list", dtos); // 핵심코드 - 포워딩 될때까지 살아 있어라
		
		}

}
