import java.util.Scanner;

/*
 * *** 계산기 ***
	수1 : 10
	수2 : 20
	연산 : +
	계산 결과 : 30
	계속 하시겠습니까? 계속 : Y , 종료 : N
 * 
 */
public class CalculatorTest {

	public static void main(String[] args) {

		int num1 = 0;
		int num2 = 0;
		int result = 0;

		String op = ""; // String 을 많이 쓰는 이유 : String 안에 엄청난 함수들이 있기 떄문

		Scanner sc = new Scanner(System.in);

		while (true) {
			try {

				System.out.println("*** 계산기 ***");
				System.out.print("수1 : ");
				num1 = sc.nextInt();

				System.out.print("수2 : ");
				num2 = sc.nextInt();

				System.out.print("연산 : ");
				op = sc.next();

				switch (op) {
				case "+":

					result = num1 + num2;
					break;

				case "-":

					result = num1 - num2;
					break;
				case "*":

					result = num1 * num2;
					break;
				case "/":

					result = num1 / num2;
					break;

				default:
					System.out.println("잘못된 연산자 입니다.");
					result = 0;
				}
				System.out.println("계산결과 " + result);

				System.out.println("계속 하시겠습니까? 계속 Y :: 중단 N");
				String finish = sc.next();

				if (finish.equals("N") || finish.equals("n")) {
					break;
				}
			} catch (Exception e) {
				System.out.println("잘못된 입력입니다. 처음부터 다시 입력해주세요.");
				continue;
			}
		} // while (true)
		System.out.println("프로그램 종료 입니다.");

	}

}
