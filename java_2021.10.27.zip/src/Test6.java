import java.util.Scanner;

/*
 * *** 계산기 ***
	수1 : 10
	수2 : 20
	연산 : +
	계산 결과 : 30
	계속 하시겠습니까? 계속 : Y , 종료 : N
 * 
 */
public class Test6 {

	public static void main(String[] args) {

		System.out.println("**********계산기**********");
		Scanner sc = new Scanner(System.in);
		while (true) {
			try {
				System.out.print("수1 : ");
				int num1 = sc.nextInt();

				System.out.print("수2 : ");
				int num2 = sc.nextInt();

				System.out.print("연산 : ");
				String ch = sc.next();

				if (ch.equals("+")) {
					int sum = num1 + num2;
					System.out.println("계산결과 : " + sum);
				} else if (ch.equals("-")) {
					int sum = num2 - num1;
					System.out.println("계산결과 : " + sum);
				} else if (ch.equals("*")) {
					int sum = num1 * num2;
					System.out.println("계산결과 : " + sum);
				} else if (ch.equals("/")) {
					int sum = num1 / num2;
					System.out.println("계산결과 : " + sum);
				} else if (ch.equals("%")) {
					int sum = num1 % num2;
					System.out.println("계산결과 : " + sum);
				} else {
					System.out.println("잘못된 연산기호 입니다.");
				}
				System.out.println("계속 하시겠습니까? 계속 Y :: 중단 N");

			} catch (Exception e) {
				System.out.println("잘못된 입력입니다. 다시 입력해 주세요");
			}

			char ch2 = sc.next().charAt(0); // 문자열을 받고 그중 1번째 문자를 받겟다.

			if (ch2 == 'N' || ch2 == 'n')
				break;
		}
		System.out.println("종료 입니다.");
	}

}
