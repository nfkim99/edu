class Circle2{
	private double r;

	public Circle2(double r) {
		this.r = r;
		
	}
	
	public double getArea() {
		double result = r * r* Math.PI;
		return result;
	}
	
	@Override
	public String toString() {
		return "넓이는" + getArea() + "입니다.";
	}


}

public class ExTest_38 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Object obj = new Circle2(10);
		System.out.println(obj);
	}

}
