
/*
interface AreaGetable{
double getArea();
}
*/

// 인터페이스 = 다형성 + 함수오버라이딩
interface AreaGetable{
    double getArea();
}


class Circle implements AreaGetable{
   private double r;
   
   public Circle(double r) {
      this.r = r;
   }
   
   @Override
   public double getArea() {
      
      return r * r * Math.PI;
   }   
}

class Rectangle implements AreaGetable{
   
   private double width,height;
   
   public Rectangle(double width,double height) {
      this.height = height;
      this.width = width;
   }
   
   @Override
   public double getArea() {
      // TODO Auto-generated method stub
      return width * height;
   }   
}




public class Test2 {
	
	public static double getAllArea(AreaGetable[] area) {
		double sum = 0;
		
		for(int i = 0; i < area.length; i++) {
			sum += area[i].getArea();
		}
		
		return sum;

	}	

	private static double getArea(AreaGetable area) {
		// TODO Auto-generated method stub
		return area.getArea();
	}

	public static void main(String[] args) {

	       AreaGetable[] area = {new Rectangle(4,5),new Circle(4)};
	       
	       //AreaGetable oneArea = new Circle(4);
	       System.out.println(getAllArea(area)); //내부함수
	       System.out.println(getArea(new Rectangle(4,5)));
	       System.out.println(getArea(new Circle(10)));

	       

	       //oneArea = new Rectangle(4,5);
	       //System.out.println(area.getArea());   
	
	}




}
