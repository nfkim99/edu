/*
아래의 인터페이스에 맞추어(상속하여) 
아래를 프로그래밍 하시오.

Circle, Rectangle , Triangle

*/

interface AreaGetable5{
    double getArea();
}


class Circle5 implements AreaGetable5{
   private double r;
   
   public Circle5(double r) {
      this.r = r;
   }
   
   @Override
   public double getArea() {
      
      return r * r * Math.PI;
   }   
}

class Rectangle5 implements AreaGetable5{
   
   private double width,height;
   
   public Rectangle5(double width,double height) {
      this.height = height;
      this.width = width;
   }
   
   @Override
   public double getArea() {
  
      return width * height;
   }   
}


class CondOp {
	
	 public static double getAllArea(AreaGetable5[] area) {
		 int sum = 0;
		 
		 for (AreaGetable5 areaGetable5 : area) {
			sum += areaGetable5.getArea();
			
		}
		 
		 for(int i = 0; i < area.length; i++) {
			 sum+= area[i].getArea();
		 }
		 return sum;
	 }
	 
	 
	 
	 
		private static double getArea(AreaGetable5 area) {
			return area.getArea();
		}


    public static void main(String[] args) {
       
       AreaGetable5[] area = {new Rectangle5(4,5),new Circle5(4)};
       
       //AreaGetable oneArea = new Circle(4);
       System.out.println( getAllArea(area) );
       System.out.println(getArea(new Rectangle5(4,5)));
       System.out.println(getArea(new Circle5(10)));
       
       //oneArea = new Rectangle(4,5);
       //System.out.println(area.getArea());      
       
    }
   
}