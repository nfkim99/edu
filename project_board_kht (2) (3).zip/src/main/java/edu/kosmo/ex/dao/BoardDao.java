package edu.kosmo.ex.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import edu.kosmo.ex.dto.BDto;

public class BoardDao {
	
	private DataSource dataSource;
	Connection connection = null;
	PreparedStatement preparedStatement = null;
	ResultSet rs = null;
	  String query = null;
	   
	  public void closeDB() {
	    try {
	      if(rs != null) rs.close();
	      if(preparedStatement != null) preparedStatement.close();
	      if(connection != null) connection.close();
	    } catch (SQLException e) {
	      e.printStackTrace();
	    }
	  }
	   
	  public ArrayList<BDto> getList(int startRow, int endRow) {
	 
	    ArrayList<BDto> list = new ArrayList<BDto>();
	     
	    try {
	    	connection = dataSource.getConnection();
	       
	    	query = "select * from mvc_board order by bGroup desc, bStep asc";
	       
	      preparedStatement = connection.prepareStatement(query);
			rs = preparedStatement.executeQuery();
	       
	      while(rs.next()) {
	    	  int bid = rs.getInt("bid");
				String bname = rs.getString("bname");
				String btitle = rs.getString("btitle");
				String bcontent = rs.getString("bcontent");
				Timestamp bdate = rs.getTimestamp("bdate");
				int bhit = rs.getInt("bhit");
				int bgroup = rs.getInt("bgroup");
				int bstep = rs.getInt("bstep");
				int bindent = rs.getInt("bindent");
	         
				BDto dto = new BDto(bid, bname, btitle, bcontent, bdate, bhit, bgroup, bstep, bindent);
				list.add(dto);
	      }
	       
	    } catch (Exception e){
	      e.printStackTrace();
	    } finally {
	      closeDB();
	    }
	    return list;
	  }
	   
	  public int getTotalCount(){
	    int total = 0;
	     
	    try {
	    	connection = dataSource.getConnection();
	       
	    	query = "select count(*) from mvc_board";
	    	preparedStatement = connection.prepareStatement(query);
	    	rs = preparedStatement.executeQuery();
	    	
	      if(rs.next()){
	        total = rs.getInt(1);
	      }
	    } catch (Exception e){
	      e.printStackTrace();
	    } finally {
	      closeDB();
	    }
	    return total;
	  }

}
