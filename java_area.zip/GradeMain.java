package java_area;

public class GradeMain {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int kor = 50; //국어 : 50
		int eng = 70; //영어 : 70
		int meth = 95; // 수학 : 95
		
		int sum = kor + eng + meth;
		double avg = (double)sum / 3;
		//double avg2 = sum / 3.0; 이렇게 해도 된다.
		
		System.out.println("총점: " + sum);
		System.out.println("평균: " + avg);
		//System.out.println("평균: " + avg2);

	}

}
