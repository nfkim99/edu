package java_area;

public class CircleArea {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double r = 5.6;	// 변수 초기화
		final double PI = 3.14;	// 상수
		//double circle = PI * (r*2);
		double area = r * r * PI;
		
		//System.out.println(circle);
		System.out.println(area);

	}

}
