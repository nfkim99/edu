package java_area;

public class CompAssignOp {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		short num = 10; 
		num = (short)(num + 77L);	// 형 변환(명시적) 안하면 컴파일 오류 발생
		int rate = 3;
		rate = (int) (rate * 3.5);	// 형 변환 안하면 컴파일 오류 발생 int * double = double로 변홤함
		System.out.println(num);
		System.out.println(rate);
		
		num = 10;
		num += 77L;		// 형 변환 필요하지 않다. 복합대입연산자는 명시적 형변환을 안한다.
		rate = 3;
		rate *= 3.5;	// 형 변환 필요하지 않다.
		System.out.println(num);
		System.out.println(rate);

	}

}
