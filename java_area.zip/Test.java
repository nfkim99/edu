package java_area;

public class Test {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 3;
		int b = 4;
			
		double result = a / (double)b;

		System.out.println(result);
		
		System.out.println('A'); 
		System.out.println(30); 
		System.out.println(3.14); 
		System.out.println('A' + 'A'); // 문자 + 문자 (int이하는 무조건 int 자료형으로 바꾼다.)
		
		
		

	}

}
