package java_area;

public class ArithOp {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1 = 7;
		int num2 = 3;
		// double a = (double)(num1 + num2); <-- 사칙연산 ()가 우선순위가 가장 높기때문에 형변환이 X
 		
		// 연산자 순위 가장 높은 것은 () 이다.
		//System.out.println("num1 + num2 = " + "11"); 문자열+int = 문자열이 된다. 
		System.out.println("num1 + num2 = " + (num1 + num2));
		System.out.println("num1 - num2 = " + (num1 - num2));
		System.out.println("num1 * num2 = " + (num1 * num2));
		System.out.println("num1 / num2 = " + (num1 / num2));
		System.out.println("num1 % num2 = " + (num1 % num2)); //몫이 많이 쓰임
		
		int num3 = 7;
		int num4 = 3;
		
		num3 += 1; // num3 + 1이랑 같은 의미 = num3 += 1;
		num4 *= 2;
		
		System.out.println(num3);
		System.out.println(num4);
		

	}

}
