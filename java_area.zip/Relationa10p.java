package java_area;

public class Relationa10p {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("3 >= 2 : " + (3 >=2));
		System.out.println("3 <= 2 : " + (3 <=2));
		System.out.println("7.0 == 7 : " + (7.0 == 7));
		System.out.println("7.0 != 7 : " + (7.0 != 7));
		
		boolean bool = (3 >= 2);
		System.out.println("3 >= 2 : " + bool);
		
		bool = true && true;	//	true
		System.out.println(bool);
		
		bool = true || false;	// true
		System.out.println(bool);
		
		bool = false || false;	// false
		System.out.println(bool);
		
		
		

	}

}
