package java_area;

public class Logical10p {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1 = 11;
		int num2 = 22;
		boolean result;
		
		// 변수 num1에 저장된 값이 1과 100 사이의 수인가?
		result = (1 < num1) && (num1 < 100); // 1초과 100미만
		System.out.println("1 초과 100 미만인가? " + result);
		
		// 변수 num2에 저장된 값이 2또는 3의 배수인가?
		result = ((num2 % 2) == 0) || ((num2 % 3) == 0); // 짝수표현 (2 4 6 8 10 2의배수), 홀수표현 = 3의 배수
		System.out.println("2 또는 3의 배수인가? " + result);
				
		// 변수 num1이 0 인가?
		result = !(num1 !=0);
		System.out.println("0 인가? " + result);
		
	
		int num5 = 0;
		int num6 = 0;
		boolean result2;    

		result2 = ((num5 += 10) < 0) && ((num6 += 10) > 0); //false && true
	    System.out.println("result = " + result2);
	   	System.out.println("num5 = " + num5);
	    System.out.println("num6 = " + num6); 
	    
	    result2 = ((num5 += 10) > 0) || ((num6 += 10) > 0);
		System.out.println("result = " + result2);
		System.out.println("num5 = " + num5);
		System.out.println("num6 = " + num6);

	}

}
