package java_area;

public class EscapeSequences {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * System.out.println("AB" + '\b' + 'C'); System.out.println("AB" + '\t' + 'C');
		 * System.out.println("AB" + '\n' + 'C'); System.out.println("AB" + '\r' + 'C');
		 * System.out.println(" \" hello \" "); // ""출력하는법!! -> "\"
		 */
		
		// String a = "안녕힛사영";
		int num1 = 100;
		
		long num2 = 3100000000L; // 디폴트 int 범위(21억)이 넘기때문에 숫자뒤에 L 붙인다. 
		float num3 = 1.12f;
		
		long l = 10045 / 4;
		double f = 10045 / 4;
		
		System.out.println(l);
		System.out.println(f);
		
		short n1 = 10;
		short n2 = 20;
		short n3 = (short)(n1 + n2); //명시적 형변환 <--- 여기서 (n1 + n2)는 int(4바이트)이다. (short(2바이트=16비트)) 
		
		System.out.println(n3);
		
		double PI = 3.14;
		int nux = (int)PI;
		
		System.out.println(nux); // double PI를 (int) 명시적형변환을 하여 int로 변환되어 소수점은 짤린다. 출력 : 3
		
		long lu2 = 3100000000L;
		nux = (int)lu2;
		
		System.out.println(nux);
		
		
		
				
				
		// 언제 - 연산시 두개의 타입이 다를경우
		
		// 컴퓨터는 무식 해서 반드시 연산 시 두개의 형이 일치 해야한다.
		
		//long result = num1 + num2; // int + long 내부적으로 형을 일치시킴
		
		
		System.out.println(num1 + num2); // int + long = 내부적으로 형을 일치시킴 = int 를 long으로 자동 형변환

	}

}
