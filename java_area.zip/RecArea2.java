package java_area;

public class RecArea2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num3 = 3;
		int num4 = 4;
		
		double result =  num3 / (double)num4; //num4를 double로 형변환 시켜주면 원하는 0.75가 출력된다!!!
		System.out.println(result);
		//double result =  num3 / num4; 
		//0.75가 안나오는 이유,  3 / 4 를 결과값을 받는데 메모리에서 결과값을 저장하는데 반드시 자료형이 정해짐.
		//결과는 0.75라고 주겠지만, 
		//자료형은 int / int 연산을 하게 되면 무조건 결과값을 int로 잡게 된다. 
		//즉, result에 대입하기 전에 int끼리의 연산으로 결과값을 잡는다.
		
		// 우선순위의 문제
		double result2 = (double)(num3 / num4); // 사칙연산 우선순위로 인해 처음처럼 결과값: 0.0이 된다.
		System.out.println(result2);

	}

}
