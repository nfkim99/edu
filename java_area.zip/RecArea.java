package java_area;

public class RecArea {
	/*
	 * 가로와 세로를 담는 변수 선언. 해당 변수에 임의 가로,세로값 할당
	 * 
	 * 넓이를 담는 변수 선언
	 * 
	 * 해당 넓이 출력
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double width = 100;
		double height = 200;
		double rec = width * height;
		
		
		System.out.println((int)rec);

	}

}
