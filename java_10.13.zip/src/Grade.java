public class Grade {
	int math;
	int science;
	int english;

	
	Grade(int math, int science, int english) { // 생성자. 생성자는 클래스명과 같다.
		this.math = math;
		this.science = science;
		this.english = english;
	}
	
	public double average() { // 평균 함수
		double avg = (math + science + english) / 3.0;
		//System.out.println(avg);
		return avg;
	}
	
	public String getGrade() {
		double avg = average();
		String str;
		
		if(avg >= 90) {
			str = "수 입니다.";
		} else if(avg >= 80) {
			str = "우 입니다.";
		} else {
			str = "가 입니다.";
		}
		return str;
	}
}