
class A { //객체
	int num; // 인스턴스 변수
	
	void setNum(int n) {
		num = n;
	}
	
	int getNum() {	// num 변수 의 값을 반환: num 값 확인할수있음
		return num;
	}
	
	void printNum() {	// 인스턴스 함수
		System.out.println(num);
	}
	
	
}

public class ObjTest {

	public static void main(String[] args) {
		
		A a = new A(); // 객체생성!! 여기서 A는 데이터 타입:참조형(레퍼런스), 생성자, a는 변수명
		
		//a.num = 10;  // 객처.으로 접근 a안에 10
		a.setNum(10); // set 함수로 값을 넣기!!
		a.setNum(20);
		a.setNum(10);
		
		int num = a.getNum();
		System.out.println(num);
		
		a.getNum(); // get 함수 a.num 값을 확인하는 함수!
		a.printNum(); // 출력이 10 num 값을 뿌리는 함수
		
		
		// 
		//a.num = 20;
		
		//System.out.println(a.num);
		

	}

}
