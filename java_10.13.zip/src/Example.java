class TV {
	
	String brand;
	int year;
	int inch;
	
	// 생성자 함수
	TV(String brand, int year, int inch) { 
		this.brand = brand;
		this.year = year;
		this.inch = inch; 
	}
	
	public void show() {	// show 함수
		System.out.println(brand + "에서 만든 " + year + "년형 " + inch + "인치 TV");
	}
	
	
}



public class Example {

	public static void main(String[] args) {

		// 생성자는 멤버변수 초기화;
		/*
		 * TV myTV = new TV("LG", 2017, 32); // LG에서 만든 2017년 32인치
		 * 
		 * myTV.show();
		 * 
		 * // 삼성에서 만든 2021년 78인치 변수 추가 TV yourTv = new TV("SAMSUNG", 2021, 78);
		 * 
		 * yourTv.show();
		 */
		
		int math, science, english;
		math = 90;
		science = 80;
		english = 80;
		
		Grade me = new Grade(math, science, english);
		System.out.println("평균은 " + me.average());
		System.out.println(me.getGrade()); // 우 입니다. void는 void를 리턴해서 오류남! String 리턴해줘야함!!
		
		
		

	}

}
