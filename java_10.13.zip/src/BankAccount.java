public class BankAccount { // 은행계좌 account : 계좌
	// 멤버변수
	String accNumber; 	// 계좌번호
	String ssNumber; 	// 주민번호
	// final int MAX_NUM = 100; // snake case
	String name = "김현택"; //해당 값을 읽기위해서 게터 세터 함수 만들기 //String 문자열과 char은 전혀 다른거
	int balance = 0; // 예금 잔액
	
	//BankAccount() {
	//	System.out.println("생성자 호출");
	//}
	
	BankAccount(String acc, String ss, int bal) { // 생성자 함수에서도 파라미터를 넘길수 있다.
		accNumber = acc;
		ssNumber = ss;
		balance = bal; //계좌 개설 시 예금액으로 초기화
	}
	
	public void initAccount(String acc, String ss, int bal) {
		accNumber = acc;
		ssNumber = ss;
		balance = bal; //계좌 개설 시 예금액으로 초기화
	}
	
	
	public String getName() { //게터
		return name;
	}
	public void setName(String name) { //세터
		this.name = name; // 파리미터와 인스턴스 네임이 같을 경우 인스턴스 앞에 this.name 을 붙여준다.
	}
	
	public int deposit(int amount) {	// 입금 함수
		balance += amount;
		return balance;	// 입금 후 확인할수있게 리턴값을 줌.
	}
	public int withdraw(int amount) {	// 출금 함수
		balance -= amount;
		return balance;	// 출금 후 확인할수있게 리턴값을 줌.
	}
	public int checkMyBalance() {	// 잔액확인 함수
		System.out.println("잔액 : " + balance);
		System.out.println("주민번호 : " + ssNumber);
		System.out.println("계좌번호 : " + accNumber);
		
		return balance;
	}
}
