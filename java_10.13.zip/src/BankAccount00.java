

public class BankAccount00 {
	
	public static void printNum(int num) {
		System.out.println(num);
	}
	
	// acc라는 이름으로 메모리를 띄운다. // 지역변수는 메모리에 띄운뒤, 실행범위가 끝나면 메모리에서 사라진다.
	public static void printBank(BankAccount acc) { // 함수를 만들 때 참조형(생성자)도 올수가 있다. 
		acc.checkMyBalance();
	}
	

	public static void main(String[] args) {
	
		
		// 생성자(Constructor)
		// 1. 클래스 이름 과 같은 함수 = 생성자 (BankAccount)
		// 2. 만약 개발자가 생성자를 만들지 않으면
		// 컴파일러 만들어주는 생성자가 있다. 이걸 디폴트 생성자라고 함.
		// 3. 생성자 또한 함수 이지만 기존 함수와 조금 다르다.
		//  다른점은 리턴 타입이 없음. 없으니깐 당연히 리턴 값도 없다.
		// 4. 생성자 = 멤버변수 초기화 할 때 대부분 사용

		// 5. 이미 다른 생성자를 만들어서 디폴트 생성자를 안 만들어줌!!!
		// 개발자가 생성자를 한 개라도 만들면!! 컴파일러가 생성자를 안만들어줌!!
		//BankAccount kim = new BankAccount();
		
		BankAccount yoon = new BankAccount("12-34-56", "999999-999999", 10000); // 생성자 호출
		
		BankAccount park = new BankAccount("12-34-78", "999999-399998", 10000);
		
		yoon.setName("윤딴딴");
		park.setName("박지성");
		
		//yoon.initAccount("627102-04-081288", "910705-1000000", 10000); // 초기화

		System.out.println(yoon.getName());
		System.out.println(park.getName());
		
		/*
		 * yoon = null;
		 * 
		 * if(yoon == null) { // null 체크 yoon = new BankAccount(); } else {
		 * yoon.deposit(5000); }
		 */
		// 가리키는 주소가 없음 - null이 있으면 관계를 끊음.
		// JVM 에게 해당 메모리가 정리 대상임을 알려주는 거임
		
		//System.out.println(yoon); // 해쉬코드: jvm이 내부적으로 올려주는 yoon의 가짜 주소.
		
		// 각 인스턴스의 대상으로 예금.
		yoon.deposit(5000);
		park.deposit(3000);
		
		// 각 인스턴스의 대상으로 출금
		yoon.withdraw(2000);
		park.withdraw(2000);
		
		// 각 인스턴스의 대상으로 잔액확인
		yoon.checkMyBalance();
		park.checkMyBalance();
		
		//printBank(yoon);
		
		

	}

}
