class Cricle {
	
	double r; // 반지름 r. 변수명 r로해도 됨.
	
	public double getR() {	// r의 현재값을 반환. // 게터
		return r;
	}
	public void setR(double rad) {	// 세팅 세터 //void로 하는 이유: 세팅만하니까 반환값이 필요가 없다.
		r = rad;
	}
	
	public double getArea() { //원넓이
		//final double PI = 3.14;
		return r * r * Math.PI;
	}
	
}

class Rectangle {
	
	int width; // 가로
	int height; // 세로
	
	public int getWidth() { // 오른쪽클릭 sorce -> get set 만들어줌
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getArea() { // 넓이 함수
		return height * width; // 넓이 구하는 식
	}
	
	
	
	
}


public class AreaTest {

	public static void main(String[] args) {
		
		Rectangle rec = new Rectangle();
		
		rec.setHeight(10);
		rec.setWidth(10);
		
		System.out.println(rec.getArea());
		
		rec.setHeight(20);
		rec.setWidth(20);
		
		System.out.println(rec.getArea());
		
		rec.setHeight(50);
		rec.setWidth(510);
		
		System.out.println(rec.getArea());
		
		
		System.out.println("==================================");
		
		
		Cricle circle = new Cricle(); // 객체생성
		
		circle.setR(10);
		
		double area = circle.getArea();
		System.out.println(area);
		
		circle.setR(20);
		
		//area = circle.getArea();
		System.out.println(circle.getArea());

	}

}
