public class Music {
	
	public static void main(String[] args) {
		
		Song music = new Song("Dancing Queen", "ABBA", 1978, "스웨덴");
		
		music.show();
		
	}
}