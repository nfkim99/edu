package edu.kosmo.ex.member;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@ToString
@Getter
@Setter
public class Member {
	private String name;
	private String id;
	private String pw;
	private String email;
	private int kor;
	private int eng;
	private int math;
	private int tower;
	
	
	public int getTower() {
		return tower;
	}

	public void setTower(int tower) {
		this.tower = tower;
	}

	public int sum() {
		int sum = kor + eng + math;
		return sum;
	}
	
	public double avg() {
		double avg = (kor + eng + math) / 3.0;
		
		if(avg >= 90) {
			System.out.println("수");
		} else if(avg >= 80) {
			System.out.println("우");
		} else if(avg >= 70) {
			System.out.println("미");
		} else if(avg >= 60) {
			System.out.println("양");
		}
		return avg;
	}
	
	public String grade() {
		String str = "";
		avg();
		if(avg() >= 90) {
			str = "수";
		} else if(avg() >= 80) {
			str = "우";
		} else if(avg() >= 70) {
			str = "미";
		} else if(avg() >= 60) {
			str = "양";
		}
		return str;
	}
	
	

	
	public int getKor() {
		return kor;
	}
	public void setKor(int kor) {
		this.kor = kor;
	}
	public int getEng() {
		return eng;
	}
	public void setEng(int eng) {
		this.eng = eng;
	}
	public int getMath() {
		return math;
	}
	public void setMath(int math) {
		this.math = math;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	
	
	
}
