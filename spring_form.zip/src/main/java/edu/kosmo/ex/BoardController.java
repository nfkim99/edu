package edu.kosmo.ex;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import edu.kosmo.ex.member.Member;

/**
 * Handles requests for the application home page.
 */
@Controller
public class BoardController {

	@RequestMapping("board/confirm")
	public String confirm(HttpServletRequest request, Model model) {

		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String addr = request.getParameter("addr");
		model.addAttribute("id", id);
		model.addAttribute("pw", pw);
		model.addAttribute("addr", addr);

		// model.addAttribute("pw", "1234");

		return "board/confirm"; // board/confirm.jsp
	}

	// http://localhost:8282/ex/board/check?id=abcd&pw=1234
	@RequestMapping("board/check")
	public String check(@RequestParam("id") String id, @RequestParam("pw") String pw, Model model) {

		model.addAttribute("identify", id);
		model.addAttribute("password", pw);

		// model.addAttribute("pw", "1234");

		return "board/check"; // board/confirm.jsp
	}

	@RequestMapping("member/join")
	public String join(Member member) { // 커맨드 객체

		return "member/join";  //member/join.jsp
	}
	
	@RequestMapping("member/input")
	public String input() { // 커맨드 객체

		return "member/input";  //member/join.jsp
	}
	
	
}
