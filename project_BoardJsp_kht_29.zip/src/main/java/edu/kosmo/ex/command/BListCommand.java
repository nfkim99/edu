package edu.kosmo.ex.command;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.kosmo.ex.dao.BDao;
import edu.kosmo.ex.dto.BDto;
import edu.kosmo.ex.page.PageVO;

public class BListCommand implements BCommand {
	
		@Override
		public void excute(HttpServletRequest request, HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		BDao dao = new BDao(); 
		//ArrayList<BDto> dtos = dao.list(0, 0);
		
		int pageNum = 1;
		int amount = 10;
		
		// 페이지번호를 클릭하는 경우
		if(request.getParameter("pageNum") != null && request.getParameter("amount") != null) {
			pageNum = Integer.parseInt(request.getParameter("pageNum"));
			amount = Integer.parseInt(request.getParameter("amount"));
		}
		
		// 2. pageVO생성
		ArrayList<BDto> dtos = dao.list(pageNum, amount);
		int total = dao.listTotalCount(); // 전체게시글수
		PageVO pageVO = new PageVO(pageNum, amount, total);
		
		// 3. 페이지네이션을 화면에 전달
		request.setAttribute("pageMaker", pageVO);
		
		// 화면에 가지고 나갈 list를 request에 저장 !!
		request.setAttribute("list", dtos);
		
		}

}
