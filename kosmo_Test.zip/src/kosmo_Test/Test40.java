package kosmo_Test;

import javax.print.attribute.standard.PrinterInfo;

abstract class Fruit {
	public void print() {
		
	}
}

class Grape extends Fruit {
	@Override
	public void print() {
		System.out.println("나는 포도입니다.");
	}
}

class Apple extends Fruit {
	@Override
	public void print() {
		System.out.println("나는 사과입니다.");
	}
}

class Pear extends Fruit {
	@Override
	public void print() {
		System.out.println("나는 배입니다.");
	}
}

/*
 * - 결과
	나는 포도이다.
	나는 사과이다.
	나는 배이다.
 */

public class Test40 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Fruit[] fAry = {new Grape(), new Apple(), new Pear()};
		
		for(Fruit f : fAry)
			f.print();

	}

}
