package kosmo_Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


public class Test51 {

	public static void main(String[] args) {
		Set<Integer> set = new HashSet<>();

		while(set.size() != 6) {
			int num = (int) (Math.random() * 45 + 1);
			set.add(num);
		}
		
		for (Integer num : set) {
			System.out.print(num + "\t");
		}
		
		System.out.println();
		
	}
}
