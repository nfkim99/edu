package kosmo_Test;


class DBox<L, R> {
	private L ob1;
	private R ob2;
	
	public void set(L ob1, R ob2) {
		this.ob1 = ob1;
		this.ob2 = ob2;
	}

	@Override
	public String toString() {
		return ob1 + "&" + ob2;
	}
}



public class Test44 {

	public static void main(String[] args) {

        DBox<String, Integer> box = new DBox<String, Integer>();
        box.set("Apple", 25);
        System.out.println(box);
        
        DBox<String, String> box2 = new DBox<String,String>();
        box2.set("Apple", "Orange");
        System.out.println(box2);

	}

}
