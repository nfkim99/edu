package kosmo_Test;

import java.util.ArrayList;
import java.util.List;

public class Test48 {

	public static void main(String[] args) {
		
		List<Integer> list = new ArrayList();
		
		for(int i = 1; i <= 10; i++) {
			list.add(i);
		}
		
		for(int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i));
		}

	}

}
