package kosmo_Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

class Num {
	int num;
	
	Num(int n) {
		num = n;
	}
	
	@Override
	public String toString() {

		return String.valueOf(num);
	}
	
	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return num % 3;
	}
	
	@Override
	public boolean equals(Object obj) {
		
		if (num == ((Num) obj).num) {
			return true;
		}
		return false;
	}
}

public class Test52 {

	public static void main(String[] args) {
		
		HashSet<Num> set = new HashSet<>();
        set.add(new Num(7799));
        set.add(new Num(9955));
        set.add(new Num(7799));

        System.out.println("인스턴스 수: " + set.size());

        for(Num n : set)
            System.out.print(n.toString() + '\t');

        System.out.println();

	}

}
