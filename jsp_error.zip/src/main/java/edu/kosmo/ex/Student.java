package edu.kosmo.ex;

public class Student {
	private String name;
	private int kor;
	private int math;
	private int eng;
	private int sum;
	private double avg;
	
	
	public double getAvg() {
		return (double)(math + kor + eng) / 3;
	}

	public void setAvg(double avg) {
		this.avg = avg;
	}

	public int getKor() {
		return kor;
	}

	public void setKor(int kor) {
		this.kor = kor;
	}

	public int getMath() {
		return math;
	}

	public void setMath(int math) {
		this.math = math;
	}

	public int getEng() {
		return eng;
	}

	public void setEng(int eng) {
		this.eng = eng;
	}

	public int getSum() {
		return math + kor + eng;
	}

	public void setSum(int sum) {
		this.sum = sum;
	}

	
	public Student() {
		
	}
	
	public Student(String name, int kor, int math, int eng, int sum) {
		this.name = name;
		this.kor = kor;
		this.math = math;
		this.eng = eng;
		this.sum = sum;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
