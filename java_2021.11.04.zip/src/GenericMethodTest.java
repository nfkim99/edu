import java.util.Scanner;


class Box<T> {
    private T ob;     
    public void set(T o) { ob = o; }
    public get() { return ob; }
}

...

public static void inBox(Box<? super Toy> box, Toy n) {
   box.set(n);   // 넣는 것! OK!
   Toy myToy = box.get();   // 꺼내는 것! Error!
}
