import java.util.Scanner;
import java.util.StringTokenizer;

/*
 * Scanner를 이용하여 한 라인을 읽고, 공백으로 분리된 어절이 몇 개 들어 있는지 "그만"을 입력할 때까지 반복하는 프로그램을 작성하라.
 * 
 * 출력 =========================================

>>I love Java.
어절 개수는 3
>>자바는 객체 지향 언어로서 매우 좋은 언어이다.
어절 개수는 7
>>그만
종료합니다...
[Hint] Scanner.nextLine()을 이용하면 빈칸을 포함하여 한 번에 한 줄을 읽을 수 있다.

(1) StringTokenizer 클래스를 이용하여 작성하라.

 */

public class ExTest7 {
	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		
		try {
			while (true) {

				String str = sc.nextLine();

				StringTokenizer st1 = new StringTokenizer(str, " ");

				System.out.println("어절 개수는 " + st1.countTokens());

				if (str.equals("그만")) {
					System.out.println("종료합니다...");
					break;
				}
			}
		} catch (Exception e) {
			System.out.println("잘못된 입력입니다.");
		}

	
	}
}
