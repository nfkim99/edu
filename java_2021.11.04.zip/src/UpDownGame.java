import java.util.Scanner;

class UpDown {
	private static int COUNT = 10; // 이런건 STATIC으로 선언
	private int[] arrInput; // 배열로 관리
	private int answer; // 정답

	public UpDown() {
		arrInput = new int[COUNT];
		answer = (int) (Math.random() * 100 + 1); // 1부터 100까지 난수
	}


	public void run() {

		try {

			Scanner sc = new Scanner(System.in);

			for (int i = 0; i < arrInput.length; i++) {
				System.out.println("숫자를 입력해 주세요.");
				int num = sc.nextInt();

				if (num > answer) {
					System.out.println("Down ===> " + (COUNT - i - 1) + "번 남아 있습니다.");
				} else if (num < answer) {
					System.out.println("Up ===> " + (COUNT - i - 1) + "번 남아 있습니다.");
				} else {
					System.out.println("정답입니다.");
					break;
				}

			}

		} catch (Exception e) {
			System.out.println("잘못된 입력 입니다. 처음부터 다시 입력하세요.");
			run(); // 재귀호출
		}

	}

}

// 
public class UpDownGame {
	public static void main(String[] args) {
		Scanner sc;
		UpDown game;

		while (true) {

			try {
				sc = new Scanner(System.in);

				System.out.println("게임시작 1");
				System.out.println("게임종료 2");
				System.out.println(">>>");

				int num = sc.nextInt();

				if (num == 1) {
					game = new UpDown();
					game.run();
				} else {
					System.out.println("게임을 종료 합니다.");
					break;
				}

			} catch (Exception e) {
				System.out.println("잘못된 입력입니다.");
				System.out.println("게임을 다시 시작 합니다.");
			}

		}
	}

}
