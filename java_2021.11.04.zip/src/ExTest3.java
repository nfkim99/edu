import java.util.Scanner;

class Box7<T1> {
	private T1 ob1;

	public T1 get() {
		return ob1;
	}

	public void set(T1 o) {
		ob1 = o;
	}
}


/*
 * 출력 =========================================

99 & 55
55 & 99

 */

public class ExTest3 {
	public static void main(String[] args) {

		Box7<Integer> box1 = new Box7<>();
        box1.set(99);

        Box7<Integer> box2 = new Box7<>();
        box2.set(55);

        System.out.println(box1.get() + " & " + box2.get());
        swapBox(box1, box2); 
        System.out.println(box1.get() + " & " + box2.get());

	}

	private static <T> void swapBox(Box7<T> box1, Box7<T> box2) {
		
		// 스왑 알고리즘
		T temp = box1.get();
		box1.set(box2.get());
		box2.set(temp);
	}
}
