/*
 * 1. class 명을 만든다.
 * 2. 데이터 멤버(인스턴스 변수)를 반드시 만든다.
 * 3. 생성자를 만든다.
 * 4. 데이터 멤버(인스턴스 변수)를 컨트롤 하는 함수를 만든다. ex) 출력함수
 * 5. 다른 소스 클래스를 그냥 대놓고 뺏겨 본다.
 * 
 * 
 * 컴파일러가 공짜로 해주는 거
 * 1. 자동 형변환
 * 2. 디폴트 생성자
 * 3. 상속시-디폴트 super 생성자
 * 4. extends Object
 * 
 */
class Friend {
	private String name, phone;
	
	public Friend(String na, String ph) {
		name = na;
		phone = ph;
	}
	public void showInfo() {
		System.out.println("이름: " + name);
		System.out.println("전화: " + phone);
	}
}

class UnivFriend2 extends Friend {
	private String major;
	
	public UnivFriend2(String na, String ma, String ph) {
		super(na, ph);
		major = ma;
	}
	@Override
	public void showInfo() {
		super.showInfo();
		System.out.println("전공: " + major);
	}
}

class CompFriend2 extends Friend {
	private String department;
	
	public CompFriend2(String na, String de, String ph) {
		super(na,ph);
		department = de;
		
	}
	@Override
	public void showInfo() {
		super.showInfo();
		System.out.println("부서: " + department);
	}
}
public class FriendTest {

	public static void main(String[] args) {
        int cnt = 0;
        Friend[] frns = new Friend[10];
        
        frns[cnt++] = new UnivFriend2("LEE", "Computer", "010-333-555");
        frns[cnt++] = new UnivFriend2("SEO", "Electronics", "010-222-444");
        frns[cnt++] = new CompFriend2("YOON", "R&D 1", "02-123-999");
        frns[cnt++] = new CompFriend2("PARK", "R&D 2", "02-321-777");


        // 모든 동창 및 동료의 정보 전체 출력
        for(int i = 0; i < cnt; i++) {
            frns[i].showInfo();
            System.out.println();
        }


	}
}

