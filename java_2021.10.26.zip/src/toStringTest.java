
class C extends Object {
	
	
}

public class toStringTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		C c = null;
		System.out.println(c);

	}

}
