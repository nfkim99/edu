package edu.kosmo.ex;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Lotto {
	// 1. 가위 2. 바위 3. 보
	private int lotto;
	private Set<Integer> lottoSet = new HashSet<Integer>();
	//private String rsp;
	JLabel imgLbl = new JLabel();
	ImageIcon bsImg = new ImageIcon(Lotto.class.getResource("/edu.kosmo.ex/img/연습용_공.png"));
	public Lotto() {
		this.lotto = (int)(Math.random() * 45 + 1); // 45 부터 1까지 랜덤함수 생성한다
		
		while(lottoSet.size() != 6) {
			int num = (int) (Math.random() * 45 + 1);
			if(num <= 10) {
				imgLbl.setIcon(bsImg);
			}
			lottoSet.add(num);
		}
	}

	public Set<Integer> getLottoSet() {
		return lottoSet;
	}

	public void setLottoSet(Set<Integer> lottoSet) {
		this.lottoSet = lottoSet;
	}


	
	public String result() { // 비교 후 출력하는 부분
		
		String num2 = "";
		Set<Integer> set = new HashSet<>();
		

		while(set.size() != 6) {
			int num = (int) (Math.random() * 45 + 1);
			set.add(num);
		}
		
		for (Integer num : set) {
			System.out.print(num + "\t");
			num2 += num + " ";
		}
		
		System.out.println();
		
		return num2;
		

	}

}
