package edu.kosmo.ex;

public class Circle{
	private double r;

	public Circle(double r) {
		this.r = r;
		
	}
	
	public double getArea() {
		double result = r * r * Math.PI;
		return result;
	}
	
	@Override
	public String toString() {
		return "넓이는 " + getArea() + "입니다.";
	}


}
