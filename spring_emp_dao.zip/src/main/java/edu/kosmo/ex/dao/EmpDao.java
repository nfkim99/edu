package edu.kosmo.ex.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.springframework.stereotype.Repository;

import edu.kosmo.ex.vo.EmpVO;


// repository = persistance = mapper = dao
// ioc 컨테이너역할 = 자동으로 객체를 생성및 관리한다.

@Repository // 객체생성시키기 위해 @컨트롤러처럼 다룬다 **제일 중요**
public class EmpDao {
	private DataSource dataSource; // 커넥션 풀
	
	public EmpDao() {
		try {
			Context context = new InitialContext();
			dataSource = (DataSource)context.lookup("java:comp/env/jdbc/oracle");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public ArrayList<EmpVO> selectList() {
		ArrayList<EmpVO> empList = new ArrayList<EmpVO>();
		
		Connection connection = null;
		PreparedStatement preparedstatement = null;
		ResultSet rs = null;
		
		try {

			String query = "select * from emp";
			
			connection = dataSource.getConnection();
			preparedstatement = connection.prepareStatement(query);
			rs = preparedstatement.executeQuery();

			
			while(rs.next()) {
				
				int empno = rs.getInt("empno");
				String ename = rs.getString("ename");
				String job = rs.getString("job");
				int mgr = rs.getInt("mgr");
				Timestamp hiredate = rs.getTimestamp("hiredate");
				int sal = rs.getInt("sal");
				int comm = rs.getInt("comm");
				int deptno = rs.getInt("deptno");
				
				EmpVO emp = new EmpVO(empno,ename,job,mgr,hiredate,sal,comm,deptno);
				
				empList.add(emp);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				
				if (preparedstatement != null)
					preparedstatement.close();
				
				if (connection != null)
					connection.close();
				
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
				
		return empList;
	}


	public EmpVO selectEmp(String num) {
		EmpVO emp = null;

		Connection connection = null;
		PreparedStatement preparedStatement = null;
		ResultSet rs = null;

		try {
			String query = "select * from emp where empno = ?";

			connection = dataSource.getConnection();
			preparedStatement = connection.prepareStatement(query);
			preparedStatement.setInt(1, Integer.valueOf(num));

			rs = preparedStatement.executeQuery();

			while (rs.next()) {

				int empno = rs.getInt("empno");
				String ename = rs.getString("ename");
				String job = rs.getString("job");
				int mgr = rs.getInt("mgr");
				Timestamp hiredate = rs.getTimestamp("hiredate");
				int sal = rs.getInt("sal");
				int comm = rs.getInt("comm");
				int deptno = rs.getInt("deptno");

				emp = new EmpVO(empno,ename,job,mgr,hiredate,sal,comm,deptno);

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (preparedStatement != null)
					preparedStatement.close();
				if (connection != null)
					connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}

		return emp;
	}

}



