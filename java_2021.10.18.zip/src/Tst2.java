import java.util.Scanner;

public class Tst2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc = new Scanner(System.in);

		int r = sc.nextInt();
		int x = sc.nextInt();
		System.out.println(r);
		System.out.println(x);

	}

}
