package edu.kosmo.ex.main;

public class CompString {

	public static void main(String[] args) {
		String st1 = "Lexicographically"; //사전
		String st2 = "lexicographically";
		int cmp;
		
		if(st1.equals(st2)) // 문자열 자체 비교
			System.out.println("두 문자열은 같습니다.");
		else
			System.out.println("두 문자열은 다릅니다.");
		
		cmp = st1.compareTo(st2); // st1과 st2를 비교하여 다른 문자열을 찾음!
		System.out.println(cmp);
		
		if(cmp == 0) { // 다른게 없다
			System.out.println("두 문자열은 일치합니다.");
		} else if(cmp < 0) { // 음수면 상대방보다 앞이라는 뜻
			System.out.println("사전의 앞에 위치하는 문자: " + st1);
		} else // 양수 = 내가 앞에있다는 뜻
			System.out.println("사전의 앞에 위치하는 문자: " + st2);
		
		if(st1.compareToIgnoreCase(st2) == 0) // 대소문자 무시 하고 비교
			System.out.println("두 문자열은 같습니다.");
		else
			System.out.println("두 문자열은 다릅니다.");

	}

}
