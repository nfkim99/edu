package edu.kosmo.ex.main;

import java.util.Scanner;

import edu.kosmo.ex.rsp.Mybalance;


public class ExTest3 {

	public static void main(String[] args) {
		/*
		 * 
		 * 10.사용자로부터 키를 입력 받아서 표준 체중을 계산한 후에 사용자의 체중과 비교하여 
			저체중인지, 표준 인지, 과체중인지를 판단하는 프로그램을 작성하라. 
			표준 체중 계산식은 다음을 사용하라.
			표준체중(kg) = ( 키(cm) - 100 ) * 0.9
			입력:
			키(cm)를 입력하세요. : 193
			체중(kg)을 입력하세요. : 25
			출력:
			표준 체중은 83.7입니다.
			당신은 저체중 입니다. 
		 * 
		 * 
		 */
		
		Scanner sc = new Scanner(System.in);

		int tall = sc.nextInt();
		int kg = sc.nextInt();
		System.out.println("키(cm)를 입력하세요. : " + tall);
		System.out.println("체중(kg)을 입력하세요. : " + kg);
		
		//double result = (tall - 100) * 0.9;
		
		
		Mybalance mb = new Mybalance(tall, kg);
		//mb.balance();
		mb.getGrade();
		
		
		
		
	}

}
