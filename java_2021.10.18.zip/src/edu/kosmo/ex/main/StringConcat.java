package edu.kosmo.ex.main;

public class StringConcat {

	public static void main(String[] args) {
		// 원본은 절대 훼손하지 않는다.
		
		String st1 = "Coffee";
		String st2 = "Bread";
		
		String st3 = st1.concat(st2);
		System.out.println(st3);
		
		String st4 = "Fresh".concat(st3); //리터럴
		System.out.println(st4);
		
		String str = "abcdefg";
		str.substring(2);
		System.out.println(str);
		
		str.substring(2, 4);
		System.out.println(str);

	}

}
