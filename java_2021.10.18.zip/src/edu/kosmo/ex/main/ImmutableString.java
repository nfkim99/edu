package edu.kosmo.ex.main;

public class ImmutableString {

	public static void main(String[] args) {
		// 원본 보전 (Immutable)
		
		String str1 = "Simple String"; // " "들어가는 한해서만
		String str2 = "Simple String"; // 안에 내용을(주소값을 비교) 비교해서 메모리에 한개만 올라간다. 2000번지
		
		String str3 = new String("Simple String"); // 객체 생성 new 는 무조건 메모리에 하나를 올린다. 2000번지.
		String str4 = new String("Simple String"); // 객체 생성 3000번지.
		
		String str5 = str1 + str2; // 원본 보전 (Immutable) String 연산은 원본을 보전
		
		System.out.println(str5);
		
		if(str1.equals(str4)) // 문자열 비교는 .equals 써야함
			System.out.println("같은 글자입니다.");
		else
			System.out.println("다른 글자입니다.");
		
		if(str1 == str2) // == 안에있는 주소 값을 비교, 
			System.out.println("str1과 str2는 동일 인스턴스 참조");
		else
			System.out.println("str1과 str2는 다른 인스턴스 참조");
		
		if(str3 == str4)
			System.out.println("str3과 str4는 동일 인스턴스 참조");
		else
			System.out.println("str3과 str4는 다른 인스턴스 참조");
	}

}
