package edu.kosmo.ex.main;

import java.util.Scanner;

public class ExTest2 {

	public static void main(String[] args) {
		// ABCD 입력
		// DCBA 출력
		
		Scanner sc = new Scanner(System.in);

		String str = sc.next();
		
		int count = 0;
		
		for(int i = 0; i < str.length(); i++) {
			//System.out.print(str.charAt(i));
			count++;
			
		}
		System.out.println("총 글자수는 : " + count + "개");
		
		/*
		for(int i = str.length() -1; i >= 0; i--) {
			System.out.print(str.charAt(i));
		}
		*/
	}

}
