package edu.kosmo.ex.main;

import edu.kosmo.ex.rsp.Person;

// 하나의 파일에 클래스가 2개 이상이면,
// 반드시 하나에만 public을 붙일 수가 있음!! = 파일 1개당 public은 1개
// 관습적임. - 다른쪽에서 접근 하는 진입 점으로 생각함.

class A {
	
}

public class Test {

	public static void main(StringTest[] args) {
	
		// 여권 있는 사람의 정보를 담은 인스턴스 생성
		Person jung = new Person(335577, 112233);
		
		// 여권 없는 사람의 정보를 담은 인스턴스 생성
		Person hong = new Person(775544);
		
		jung.showPersonalInfo();
		hong.showPersonalInfo();

	}

}
