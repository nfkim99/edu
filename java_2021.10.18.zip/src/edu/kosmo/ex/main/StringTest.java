package edu.kosmo.ex.main;



public class StringTest {
	
	// static 이 붙는 이유는 시간차가 있기 때문에
	// 인스턴스변수는 static뒤에 메모리에 올라가기 때문에, 
	// 반드시 static을 선언해준다.
	public static void showString(String str) {
		System.out.println(str);
		System.out.println(str.length());

	}

	// 함수 오버 로딩 = 우리가 쓰는 가장 대표적인거 함수 = println : 가장 대표적인 함수오버로딩
	// 오버로딩 = 같은 함수이름으로 형과 갯수가 다른거
	public static void main(java.lang.String[] args) {
		
		showString("Funny String");
		
		String str1 = new String("Simple String");
		String str2 = "The Best String";
		
		System.out.println(str1);
		System.out.println(str1.length()); // 문자열의 갯수
		System.out.println();	// '개 행'
		
		System.out.println(str2);
		System.out.println(str2.length());
		System.out.println();

	}

}
