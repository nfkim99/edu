package edu.kosmo.ex.main;
import java.util.Scanner;

import edu.kosmo.ex.rsp.Player;

public class RSPTest {

	public static void main(String[] args) {

		while (true) {

			Scanner sc = new Scanner(System.in);

			System.out.println("가위 바위 보를 입력하세요.");
			String rsp = sc.next();

			Player user = new Player(rsp); // 사람.
			Player com = new Player(); // 컴퓨터

			com.result(user);
			
			System.out.println("계속 Y :: 중단 N");
			char ch = sc.next().charAt(0); // 문자열을 받고 그중 1번째 문자를 받겟다.
			
			if(ch == 'N' || ch == 'n')
				break;
		}
		
		
		
		System.out.println("게임 종료 입니다.");
	}

}
