package edu.kosmo.ex.main;

import java.util.Scanner;

public class ExTest1 {

	public static void main(String[] args) {

	
		
		while (true) {
			
			Scanner sc = new Scanner(System.in);

			int money = sc.nextInt();

			// int money = 126_500;
			
			System.out.println("오만원 : " + money / 50000 + "장");
			money = money % 50000;
			System.out.println("만원 : " + money / 10000 + "장");
			money = money % 10000;
			System.out.println("오천원 : " + money / 5000 + "장");
			money = money % 5000;
			System.out.println("천원 : " + money / 1000 + "장");
			money = money % 1000;
			System.out.println("오백원 : " + money / 500 + "장");
			money = money % 500;
			System.out.println("백원 : " + money / 100 + "장");
			money = money % 100;

			//System.out.println(money);

			System.out.println("계속 Y :: 중단 N");
			char ch = sc.next().charAt(0); // 문자열을 받고 그중 1번째 문자를 받겟다.

			if (ch == 'N' || ch == 'n')
				break;
		}
		System.out.println("종료 입니다.");

	}

}
