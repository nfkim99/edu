package edu.kosmo.ex.rsp;

public class Player {
	// 1. 가위 2. 바위 3. 보
	private int rsp;
	//private String rsp;
	
	// 1. 같은 함수 이름 파라미터의  type 또는 갯수를 달리 하는 것.
	
	public void printRSP(int a) {
		
	}
	
	public int printRSP() { // return타입이랑은 상관없다.
		return 0;
	}
	
	public Player(String rsp) {
		if(rsp.equals("가위")) { // String 문자열 비교는 equals 사용!!
			this.rsp = 1;
		} else if(rsp.equals("바위")) {
			this.rsp = 2;
		} else {
			this.rsp = 3;
		}
		
	}
	
	public Player() {
		this.rsp = (int)(Math.random() * 3 + 1); // 1 부터 3까지 랜덤함수 생성한다
	}
	
	private String getRSPString(int rsp) {
	     String str = "";
	    
	     if(rsp == 1)
	     str = "가위";
	     else if(rsp ==2)
	     str = "바위";
	     else
	     str = "보";
	    
	     return str;
	    }

	
	public void result(Player player) { // 비교 후 출력하는 부분
		
		System.out.println("나는:" +  getRSPString(this.rsp) + " 당신은:" + getRSPString(player.rsp));
		
		if(this.rsp == player.rsp) {
			System.out.println("비겼습니다.");
			return;
		}
		
		// 1. 가위 2. 바위 3.보
		if(this.rsp == 1 && player.rsp == 2) {
			System.out.println("제가 졌습니다.");
		} else if(this.rsp == 1 && player.rsp == 3) {
			System.out.println("제가 이겼습니다.");
		} else if(this.rsp == 2 && player.rsp == 1) {
			System.out.println("제가 이겼습니다.");
		}  else if(this.rsp == 2 && player.rsp == 3) {
			System.out.println("제가 졌습니다.");
		}  else if(this.rsp == 3 && player.rsp == 1) {
			System.out.println("제가 졌습니다.");
		}  else if(this.rsp == 3 && player.rsp == 2) {
			System.out.println("제가 이겼습니다.");
		}
		
		
		
		
		
		
	}

}
