package edu.kosmo.ex.rsp;
public class Mybalance {
	int tall;
	int kg;

	
	public Mybalance(int tall, int kg) { // 생성자. 생성자는 클래스명과 같다.
		this.tall = tall;
		this.kg = kg;
	}
	
	public double balance() { // 평균 함수
		double result = ( tall - 100 ) * 0.9;
		System.out.println("표준 체중은 " + result + "입니다.");
		return result;
	}
	
	public String getGrade() {
		double avg = balance();
		String str;
		
		if(avg <= 85) {
			str = "당신은 저 체중 입니다.";
			System.out.println(str);
		} else if(avg >= 90){
			str = "당신은 표준 체중 입니다.";
			System.out.println(str);
		} else {
			str = "당신은 고 체중 입니다.";
			System.out.println(str);
		}
		return str;
	}
}