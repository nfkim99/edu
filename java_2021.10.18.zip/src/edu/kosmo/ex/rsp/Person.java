package edu.kosmo.ex.rsp;


public class Person {
	private int regiNum;
	private int passNum;
	
	public Person(int rnum, int pnum) {
		this.regiNum = rnum;
		this.passNum = pnum;
	}
	
	public Person(int rnum) {
		//regiNum = rnum;
		//passNum = 0;
		this(rnum, 0); // this 생성자함수 = 자기 객체 내부에서 자기 자신의 생성자 호출
	}
	
	void aa() {
		System.out.println("test");
	}
	
	public void showPersonalInfo() {
		this.aa(); // 자기 자신
		
		System.out.println("주민등록 번호: " + regiNum);
	}

}
