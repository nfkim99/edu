
public class Rant {
	int width;
	int height;
	
	Rant(int width, int height) {
		this.width = width;
		this.height = height;
	}
	
	public int square() {
		return width * height;
	}
	

}
