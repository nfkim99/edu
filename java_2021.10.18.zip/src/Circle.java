
public class Circle {
	int r;
	
	public Circle(int r) {
		this.r = r;
		
	}
	
	public int show() {
		int result = (int) (r * r * Math.PI);
		return result;
	}
	

}
