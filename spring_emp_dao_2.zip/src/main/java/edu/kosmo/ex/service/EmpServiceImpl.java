package edu.kosmo.ex.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import edu.kosmo.ex.dao.EmpDao;
import edu.kosmo.ex.mapper.EmpMapper;
import edu.kosmo.ex.vo.EmpVO;

// 스프링에선
// command 부분 = service로 구현

@Service // - @Service 를 해줘야 IOC 컨테이너에서 읽는다
public class EmpServiceImpl implements EmpService {
	
	//@Autowired  // EmpDao 자동으로 인젝션시킨다 주입. 스프링에선 new 안씀
	//private EmpDao empDao;
	@Autowired
	private EmpMapper empMapper;
	
	@Override
	public List<EmpVO> getList() {
		
		System.out.println("getList() ..");
		return empMapper.selectList();
	}
	
	@Override
	public EmpVO getEmp(String empno) {
		
		System.out.println("getEmp() ..");
		return empMapper.selectEmp(Integer.valueOf(empno));
	}
	
}



